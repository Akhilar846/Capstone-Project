<?php   
?>
<!-- home banner start here -->
<div class="home-banner"> <img src="./assets/images/banner2.png" /> </div>
<!-- home banner image html end here -->

<!-- home content start here --> 
<div class="main-container">
  <div class="content-part">
    <h2>About our Store</h2>
    <p>Daawat offers meals of excellent quality and invites you to try its delicious Authentic East Indian food. 
The key to our success is simple: providing quality consistent food that taste great every single time. We pride ourselves on serving our customers delicious and tasty food. We thank you from the bottom of our hearts for your continued support. 

Over 100 years of collective experience in culinary art and dedication have produced the most authentic cuisine. This enables us to present each dish with a different taste and flavour. At Daawat, all our delicious chicken dishes are made with 100% natural chicken breast, we also use freshly ground rare Indian spices, herbs and hand picked ingredients to give you the distinguished taste. 

At Daawat, our goal is to your favourite Authentic East Indian Restaurant. To do this, we know that we must give you a variety of great tasting quality food, served by a knowledgeable and friendly staff, giving the best customer service at a fair and resonable price everytime you visit !</p>
    <div class="home-button"> <a class="button" href="index.php?page=products">Browse our store</a> </div>
  </div>
</div>
<!-- home content end here -->

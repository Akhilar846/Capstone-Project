<?php

if ($_SERVER['REQUEST_METHOD'] == 'POST'){
    require('/db/db.php');
    if(empty($_POST['firstname'] && $_POST['lastname'] && $_POST['email'] && $_POST['birthdate'] && $_POST['mobile'] && $_POST['password'])){
        echo "Fields Should not be empty!";
    }
    else{
        $firstname = $_POST['firstname'];
        $lastname = $_POST['lastname'];
        $email = $_POST['email'];
        $birthdate = $_POST['birthdate'];
        $mobile = $_POST['mobile'];
        $password = $_POST['password'];
	
	 $q = "INSERT INTO registration (firstname, lastname, email, birthdate, mobile, password) values ('$firstname','$lastname','$email', '$birthdate', '$mobile', '$password')";
    $r = mysqli_query($conn, $q);
        //echo 'Registration Succ ';
        
     header("login.php");

}
}
?>
<html>
<div class="main-container"> 
<div class="content-part">
    <form class="form" action="" method="POST">
    
<!-- shipping address start here -->
<div class="checkout-address">
    <div class="checkout-address-inner">
        <h3>Registration</h3>
          <div class="text-field">
            <label for="firstname">First Name</label>
            <input type="text" name="firstname" pattern="[A-Za-z]{1,50}" required="required">
          </div>
          <div class="text-field">
            <label for="lastname">Last Name</label>
            <input type="text" name="lastname" pattern="[A-Za-z]{1,50}">
          </div>
          <div class="text-field">
            <label for="email">Email</label>
            <input type="text" name="email" required="required">
          </div>
          <div class="text-field">
            <label for="birthdate">Birthdate</label>
            <input type="text" name="birthdate" required="required">
          </div>
         <div class="text-field">
            <label for="mobile">Mobile</label>
            <input type="text" name="mobile" required="required">
          </div>
         <div class="text-field">
            <label for="password">Password</label>
            <input type="password" name="password" required="required">
          </div>
     </div>
</div>

<!-- submit button html start here -->
	<div class="text-field-button">
	<input class="button" type="submit" name="register" value="Register">
	</div>
<!-- submit button html end here -->

	</form>  
</div>
</div>
</html>
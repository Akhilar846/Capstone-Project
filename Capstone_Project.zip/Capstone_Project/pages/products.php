<?php 
  	session_start(); 
    require("db/db.php");
    $sql="SELECT * FROM products ORDER BY name ASC"; 
    $query=mysqli_query($conn, $sql); 
 ?>
<div class="main-container">
    <div class="content-part">
        <h1>Food for you</h1>
        <p>For an authentic, yet casual, Indian dining experience a visit to one of our Daawat Restaurants is a must. Whether its to snack on one of India's famous appetizers or simply savouring a delicious meal, spiced to your liking, Daawat is a sure hit to please anyone’s palette.
            Each location is fully licensed and unique to cater your every need.</p>
        <?php
		while ($row=mysqli_fetch_array($query)) { 
	?>
        <div class="product-box">
            <div class="product-img" style="background-color: antiquewhite;"> <img src="<?php echo './assets/images/'.$row['image'];?>" alt="Product image"> </div>
            <div class="product-description">
                <h4><b>In stock: </b><?php echo $row['quantity'] ?></h4>
                <h4><?php echo $row['name'] ?></h4>
                <p><?php echo $row['description'] ?></p>
                <p><?php echo $row['price'] ?> $</p>
                <?php if($row['quantity'] > 0){?>
                <a class="button" href="index.php?page=cart&action=add&id=<?php echo $row['product_id'] ?>">Add to cart</a>
                <?php } else{?>
                <input type="button" class="button disabled" value="Out of stock" disabled>
                <?php }?>
            </div>
        </div>
        <?php } 
?>
    </div>
</div>

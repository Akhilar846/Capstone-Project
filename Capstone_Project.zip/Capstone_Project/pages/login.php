<?php
 
if ($_SERVER['REQUEST_METHOD'] == 'POST'){
    require('/db/db.php');
    $email=$_POST['email'];
    $pass=$_POST['password'];
   // echo $email;
//echo $pass;
   //  $emaildb='';
  //  $passworddb='';
    
   
 $query=mysqli_query($conn, "select * from registration"); 
    $count=mysqli_num_rows ($query) ;
   // echo $count;
while ($row = mysqli_fetch_array($query)) {

     if($email == $row['email'] && $pass == $row['password'] )
    {    
        
        header("location:index.php");
    }
}

} 
?>
 
<html>
<div class="main-container"> 
<div class="content-part">
    <form class="form" action="" method="POST">
    
<!-- Login page start here -->
<div class="checkout-address">
    <div class="checkout-address-inner">
        <h3>Log In Here</h3>
          <div class="text-field">
             <div class="text-field">
            <label for="email">Email</label>
            <input type="text" name="email" required="required">
          </div>
               <div class="text-field">
            <label for="password">Password</label>
            <input type="password" name="password" required="required">
          </div>
     </div>
</div>

<!-- submit button html start here -->
	<div class="text-field-button">
	<input class="button" type="submit" name="submit" value="submit">
	</div>
<!-- submit button html end here -->

        </div>  
    </form>
</div>
    </div>
</html>

<?php 
	if(isset($_POST['place_order']) && !empty($_POST['place_order'])){
		session_start(); 
		require("db/db.php");
		$products = $_SESSION['cart'];
		foreach ($products as $key => $value) {
			$sql = "SELECT * FROM `products` WHERE `product_id`=$key";
			$res = mysqli_query($conn, $sql);
      $data = mysqli_fetch_assoc($res);
      $stock = $data['quantity'];
      $update_stock = $data['quantity'] - $value['quantity'];
      if($update_stock < 0 ){
        $update_stock = 0;
      }
      $sql = "UPDATE `products` SET `quantity`=".$update_stock." WHERE `product_id`=$key";
      $res = mysqli_query($conn, $sql);
		}
		unset($_SESSION['cart']);
	 ?>
     
<!-- After sumit form message html start here -->
<div class="main-container"> 
<div class="content-part">
  <h3>Thank you, your order has been placed!</h3>
  <div class="checkout-message">
    <div class="checkout-message-box">
      <p><b>Your First Name</b>: <?php echo $_POST['first-name'];?></p>
	  <p><b>Your Last Name</b>: <?php echo $_POST['last-name'];?></p>
      <p><b>Your email</b>: <?php echo $_POST['email'];?></p>
      <p><b>Your address</b>: <?php echo $_POST['address'];?></p>
    </div>
  </div>
</div>
</div>
<!-- After sumit form message html end here -->
<?php } else {
?>
<div class="main-container"> 
<div class="content-part">
    <form class="form" action="" method="POST">
    
<!-- shipping address start here -->
<div class="checkout-address">
    <div class="checkout-address-inner">
        <h3>Shipping details.</h3>
          <div class="text-field">
            <label for="first-name">First Name</label>
            <input type="text" name="first-name" pattern="[A-Za-z]{1,50}" required="required">
          </div>
          <div class="text-field">
            <label for="last-name">Last Name</label>
            <input type="text" name="last-name" pattern="[A-Za-z]{1,50}">
          </div>
          <div class="text-field">
            <label for="email">Email</label>
            <input type="email" name="email" required="required">
          </div>
          <div class="text-field">
            <label for="address">Address</label>
            <textarea name="address" required="required"></textarea>
          </div>
     </div>
</div>
<!-- shipping address end here -->

<!-- payment box start here -->
<div class="payment-method">
    <div class="payment-method-inner">
    	<h3>Payment Method</h3>
        <div class="payment-option-by-card">
            <input type="radio" name="card-cash" id="credit-debit-card" class="payment-by-card" checked="checked" />
            <label for="credit-debit-card">Credt/Debit Card</label>
        </div>
		
<!-- credit and debit card payment html start here -->
        <div class="payment-by-card-box" id="payment-by-card-box">
            <div class="text-field">
                <label for="card-name">Name on Card</label>
                <input type="text" name="card-name" pattern="[A-Za-z]{1,50}" required="required">
            </div>
            <div class="text-field">
                <label for="card-number">Card Number</label>
                <input type="text" name="card-number" pattern="[0-9]{16,16}" required="required">
            </div>
            <div class="text-field">
                <label for="expery-date">Expiry Date</label>
                <select name="expiry_month" class="select-month" required="required">
                        <option value="01">Jan (01)</option>
                        <option value="02">Feb (02)</option>
                        <option value="03">Mar (03)</option>
                        <option value="04">Apr (04)</option>
                        <option value="05">May (05)</option>
                        <option value="06">June (06)</option>
                        <option value="07">July (07)</option>
                        <option value="08">Aug (08)</option>
                        <option value="09">Sep (09)</option>
                        <option value="10">Oct (10)</option>
                        <option value="11">Nov (11)</option>
                        <option value="12">Dec (12)</option>
                </select>
                <select name="expiry_year" class="select-year" required="required">
                        <option>2018</option>
                        <option>2019</option>
                        <option>2020</option>
                        <option>2021</option>
                        <option>2012</option>
                        <option>2013</option>
                        <option>2014</option>
                        <option>2015</option>
                        <option>2016</option>
                        <option>2017</option>
                        <option>2018</option>
                        <option>2019</option>
                        <option>2030</option>
                </select>
            </div>
            <div class="text-field">
                <label for="CVV">CVV</label>
                <input type="text" name="CVV" required="required" pattern="[0-9]{3,3}" style="width:100px;">
            </div>
        </div>
<!-- credit and debit card payment html end here -->

<!-- cash on delivery start here -->
        <div class="payment-option-by-cash">
            <input type="radio" name="card-cash" id="credit-debit-cash" class="payment-by-cash" />
            <label for="credit-debit-cash">Cash On Delivery</label>
        </div>
<!-- cash on delivery end here -->

	</div>
</div>
<!-- payment box end here -->

<!-- submit button html start here -->
	<div class="text-field-button">
	<input class="button" type="submit" name="place_order" value="Place order">
	</div>
<!-- submit button html end here -->

	</form>  
</div>
</div>
<?php } 
?>

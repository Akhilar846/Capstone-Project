<?php

if ($_SERVER['REQUEST_METHOD'] == 'POST'){
    require('/db/db.php');
    if(empty($_POST['firstname'] && $_POST['lastname'] && $_POST['email'] && $_POST['message'])){
        echo "Fields Should not be empty!";
    }
    else{
        $firstname = $_POST['firstname'];
        $lastname = $_POST['lastname'];
        $email = $_POST['email'];
        $message = $_POST['message'];
	
	 $q = "INSERT INTO contactus (firstname, lastname, email, message) values ('$firstname','$lastname','$email','$message')";
    $r = mysqli_query($conn, $q);
     header("index.php");

}
}
?>
<html>
<div class="main-container"> 
<div class="content-part">
    <form class="form" action="" method="POST">
    
<!-- contact us form start here -->
<div class="checkout-address">
    <div class="checkout-address-inner">
        <h3>Contact Us</h3>
          <div class="text-field">
            <label for="firstname">First Name</label>
            <input type="text" name="firstname" pattern="[A-Za-z]{1,50}" required="required">
          </div>
          <div class="text-field">
            <label for="lastname">Last Name</label>
            <input type="text" name="lastname" pattern="[A-Za-z]{1,50}">
          </div>
          <div class="text-field">
            <label for="email">Email</label>
            <input type="email" name="email" required="required">
          </div>
          <div class="text-field">
            <label for="message">Message</label>
            <textarea name="message" required="required"></textarea>
          </div>
     </div>
</div>
<!-- contact us form end here -->

<!-- submit button html start here -->
	<div class="text-field-button">
	<input class="button" type="submit" name="message" value="Send Message">
	</div>
<!-- submit button html end here -->

	</form>  
</div>
</div>
</html>


<?php 
session_start(); 
require("db/db.php");
?>
<?php
if(isset($_GET['action']) && $_GET['action']=="add"){          
	$id=intval($_GET['id']);           
	if(isset($_SESSION['cart'][$id])){   
		$sql = "SELECT * FROM `products` WHERE `product_id`=$id";
		$result = mysqli_query($conn, $sql);
		$product_data = mysqli_fetch_assoc($result);
		$in_stock = $product_data['quantity'];
		$in_cart = $_SESSION['cart'][$id]['quantity'];
		if($in_cart < $in_stock) {
			$_SESSION['cart'][$id]['quantity']++; 
			$message = "Product has been added to your cart."; 
		}
		              
	}else{               
		$sql="SELECT * FROM products WHERE product_id={$id}"; 
		$query=mysqli_query($conn, $sql); 
		if(mysqli_num_rows($query) > 0){                 
			$row=mysqli_fetch_array($query);                   
			$_SESSION['cart'][$row['product_id']]=array( 
				"quantity" => 1, 
				"name" => $row['name'], 
				"price" => $row['price'] 
			); 
			$message = "Product has been added to your cart.";                  
		}else{                   
			$message="This product id it's invalid!";                   
		}               
	}           
} else if(isset($_GET['action']) && $_GET['action']=="clear"){
	unset($_SESSION['cart']);
}else if(isset($_GET['action']) && $_GET['action']=="update"){
	$products = $_POST['products'];
	$new_qty = $_POST['new_quantity'];
	for ($i=0; $i < count($products); $i++) { 
		$sql = "SELECT * FROM `products` WHERE `product_id`=$products[$i]";
		$result = mysqli_query($conn, $sql);
		$product_data = mysqli_fetch_assoc($result);
		$in_stock = $product_data['quantity'];
		$new_qty[$i];
		if($new_qty[$i] <= $in_stock){
			$_SESSION['cart'][$products[$i]]['quantity'] = $new_qty[$i];
			$message = "Cart Updated succesfully";
		} else {
			$message = "Failed to add, Some of the you are trying to add, exceed the stock limit.";
		}
	}
}
?>

<div class="main-container">
	<div class="content-part">
		<h1>Products in your cart</h1>
		<?php if(isset($message) && !empty($message)){ echo "<h4 style='color:green;'>$message</h4>";}?>
		<div class="cart-page">
			<?php 
			$products = $_SESSION['cart'];
			if(isset($products) && is_array($products)){ ?>
				<div class="cart-table">
					<form action="index.php?page=cart&action=update" method="POST">
					<table cellpadding="0" cellspacing="0" border="0">
						<thead>
							<th>Name</th>
							<th>Price</th>
							<th>Quantity</th>
						</thead>
						<tbody>
							<?php
							foreach ($products as $key => $product) { 
								?>
								<tr>
									<td><?php echo $product['name'] ?></td>
									<td><?php echo $product['price']*$product['quantity'] ?>$</td>
									<td>
										<input type="number" name="new_quantity[]" min="1" max="10" value="<?php echo $product['quantity'] ?>" class="quanty-count"/>
										<input type="hidden" name="products[]" value="<?php echo $key ?>"/>
									</td>
								</tr>
							<?php } 
							?>
						</tbody>
					</table>
					<input style="margin-bottom: 10px;padding:5px;" class="cart-page-btn button" type="submit" name="update_cart" value="Update cart"/>
					</form>
				</div>
			<?php } ?>
		</div>
		<div class="cart-bottom">
			<?php if(isset($products) && is_array($products)){ ?>
				<div class="cart-page-btn"> <a class="button" href="index.php?page=checkout" title="Place Order">Checkout</a> </div>
				<div class="cart-page-btn"> <a class="button" href="index.php?page=cart&action=clear" title="Clear cart" onclick="return(confirm('Are you sure to clear your cart?');)">Clear</a> </div>
			<?php } else{?>
				<div class="cart-page-btn">
					<h4>Your cart is empty</h4>
					<a class="button" href="index.php?page=products" title="Place Order">Shop now</a> </div>
				<?php }?>
			</div>
		</div>
	</div>

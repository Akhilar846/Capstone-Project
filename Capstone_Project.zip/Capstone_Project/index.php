<?php 
    error_reporting(0);
    if(isset($_GET['page'])){
        // echo $_GET['page']." y ";
        if(file_exists('pages/'.$_GET['page'].'.php')) {               
            $page=$_GET['page'];               
        }else{               
            $page="products"; 			
        }           
    }else{           
        $page="home";           
    }   
?>
<!DOCTYPE html>
<html>
<head>
<title>Daawat</title>
<link rel="stylesheet" href="assets/css/style.css" />
<link href="https://fonts.googleapis.com/css?family=Open+Sans:400,400i,600,700" rel="stylesheet">
<script src="assets/js/jquery.min.js"></script>
<script>
$(document).ready(function() {
	jQuery(function() {
		var pgurl = window.location.href.substr(window.location.href
		.lastIndexOf("/")+1);
		jQuery(".header ul li a").each(function(){
		if(jQuery(this).attr("href") == pgurl || jQuery(this).attr("href") == '' )
		jQuery(this).addClass("active");
    })
});
 $('input[type="radio"]').click(function() {
       if($(this).attr('id') == 'credit-debit-card') {
            $('#payment-by-card-box').show();   
       }
       else {
            $('#payment-by-card-box').hide();
			$('#payment-by-card-box input').removeAttr('required');	
       }
   });
});
</script>
</head>

<body>
<div id="main-container">

<!-- Header start here -->
  <div class="header">
    <div class="main-container">
      <div class="logo">
        <h2><a href="index.php?page=home">Daawat</a></h2>
      </div>
      <ul>
        <li> <a href="index.php?page=home">Home</a> </li>
        <li> <a href="index.php?page=products">Products</a> </li>
        <li> <a href="index.php?page=cart">Cart</a> </li>
          <li> <a href="index.php?page=registration">Registration</a> </li>
          <li> <a href="index.php?page=login">Login</a> </li>
          <li> <a href="index.php?page=contactus">Contact Us</a> </li>
      </ul>
    </div>
  </div>
<!-- Header end here -->

<!-- Inner pages start here -->
  <div class="inner-section">
    <?php require("pages/".$page.".php"); ?>
  </div>
<!-- Inner pages end here -->
  
<!-- Footer start here -->
  <div class="footer">
    <div class="main-container">
      <p>© Copyright 2019 Daawat. All rights reserved.</p>
    </div>
  </div>
<!-- Footer end here -->

</div>
</body>
</html>
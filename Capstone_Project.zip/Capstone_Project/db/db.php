<?php
	$dbHost = 'localhost';
	$dbUser = 'root';
	$dbPass = '';
	$dbName = 'daawat';
	$conn = mysqli_connect($dbHost, $dbUser, $dbPass);
	mysqli_select_db($conn, $dbName);

	if(! $conn ){
	die('Could not connect: ' . mysqli_error());
	}
?>